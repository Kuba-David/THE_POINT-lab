// načtení a uložení do localStorage
export function getCart() {
  return JSON.parse(localStorage.getItem('cart') || '[]');
}

export function saveCart(cart) {
  localStorage.setItem('cart', JSON.stringify(cart));
}

// aktualizace badge
export function updateBadge() {
  const cart = getCart();
  const totalItems = cart.reduce((sum, item) => sum + item.qty, 0);
  const badge = document.getElementById('cart-badge');
  if (!badge) return;

  badge.textContent = totalItems;
  if (totalItems > 0) badge.classList.add('visible');
  else badge.classList.remove('visible');
}

// přidání produktu
export function addToCart(id) {
  const cart = getCart();
  const existing = cart.find(item => item.id === id);
  if (existing) existing.qty++;
  else cart.push({ id, qty: 1 });
  saveCart(cart);
  updateBadge();
}

// init na každé stránce
document.addEventListener('DOMContentLoaded', () => {
  updateBadge();
});
