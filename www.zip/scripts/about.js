document.addEventListener("DOMContentLoaded", () => {
  const track = document.querySelector(".slider-track");
  const slides = document.querySelectorAll(".slide");
  const prevBtn = document.querySelector(".nav.prev");
  const nextBtn = document.querySelector(".nav.next");

  let index = 0;
  const maxIndex = slides.length - 1;

  function updateSlider() {
    const slideWidth = window.innerWidth;
    const offset = index * slideWidth;
    track.style.transform = `translateX(-${offset}px)`;

    prevBtn.disabled = index === 0;
    nextBtn.disabled = index === maxIndex;
  }

  prevBtn.addEventListener("click", () => {
    if (index > 0) {
      index--;
      updateSlider();
    }
  });

  nextBtn.addEventListener("click", () => {
    if (index < maxIndex) {
      index++;
      updateSlider();
    }
  });

  let startX = 0;
  track.addEventListener("touchstart", (e) => {
    startX = e.touches[0].clientX;
  });

  track.addEventListener("touchend", (e) => {
    const diff = e.changedTouches[0].clientX - startX;

    if (diff > 50 && index > 0) {
      index--;
      updateSlider();
    } else if (diff < -50 && index < maxIndex) {
      index++;
      updateSlider();
    }
  });

  window.addEventListener("resize", updateSlider);
  updateSlider();
});
