import './hamburger.js';
import './product-card.js';
import './about.js';
import './cart.js';
import './cartPage.js';
import './collection.js';