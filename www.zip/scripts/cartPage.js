import { getCart, saveCart, updateBadge } from './cart.js';

document.addEventListener('DOMContentLoaded', () => {
  const container = document.getElementById('cart-container');
  const totalEl  = document.getElementById('cart-total');
  // pokud chybí kontejnery, kód vůbec nepoběží:
  if (!container || !totalEl) return;

// vykreslení jedné položky
function renderCartItem(prod, qty, container) {
  const el = document.createElement('div');
  el.className = 'cart-item';
  el.innerHTML = `
    <img src="${prod.images[0]}" alt="${prod.name}" class="cart-item-img">
    <div class="cart-item-info">
      <h4>${prod.name}</h4>
      <p class="cart-item-paragraph">${prod.price} € × 
        <button class="qty-decrease">−</button>
        <span class="qty">${qty}</span>
        <button class="qty-increase">+</button>
      </p>
      <button class="remove-item">Remove</button>
    </div>
  `;
  // eventy
  el.querySelector('.qty-decrease').addEventListener('click', () => {
    updateQty(prod.id, qty - 1);
  });
  el.querySelector('.qty-increase').addEventListener('click', () => {
    updateQty(prod.id, qty + 1);
  });
  el.querySelector('.remove-item').addEventListener('click', () => {
    updateQty(prod.id, 0);
  });

  container.appendChild(el);
}

function updateQty(id, newQty) {
  let cart = getCart();
  if (newQty <= 0) {
    cart = cart.filter(item => item.id !== id);
  } else {
    cart = cart.map(item => item.id === id ? { ...item, qty: newQty } : item);
  }
  saveCart(cart);
  updateBadge();
  renderCart();      // znovu celý košík a součet
}

function renderCart() {
  const cart = getCart();
  const container = document.getElementById('cart-container');
  container.innerHTML = '';
  if (cart.length === 0) {
    container.innerHTML = '<p class="cart-empty">No point at all. 😭</p>';
    document.getElementById('cart-total').textContent = '0 €';
    updateBadge();
    return;
  }

  // načti produkty z db.json
  fetch('db.json')
    .then(res => res.json())
    .then(data => {
      let sum = 0;
      cart.forEach(item => {
        const prod = data.products.find(p => p.id === item.id);
        if (!prod) return;
        renderCartItem(prod, item.qty, container);
        sum += prod.price * item.qty;
      });
      document.getElementById('cart-total').textContent = `${sum} €`;
      updateBadge();
    });
}

  renderCart();
});
